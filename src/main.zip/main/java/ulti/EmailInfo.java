package ulti;

public class EmailInfo
{
    public String email;
    public String subject;
    public String content;

    public EmailInfo(String email,String subject, String content) {
        this.email = email;
        this.subject = subject;
        this.content = content;
    }
}